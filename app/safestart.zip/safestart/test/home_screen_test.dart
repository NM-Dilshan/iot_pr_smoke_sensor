import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:safestart/screens/home/home_screen.dart';
import 'package:safestart/screens/history/history_screen.dart';
import 'package:safestart/theme/app_theme.dart';
import 'package:safestart/widgets/dashboard_stat_card.dart';

Future<void> tapVisible(WidgetTester tester, Finder finder) async {
  await tester.pump(const Duration(seconds: 5));
  await tester.pumpAndSettle();
  await tester.ensureVisible(finder);
  await tester.pumpAndSettle();
  await tester.tap(finder);
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('Demo dashboard keeps future actions on Home', (tester) async {
    await tester.pumpWidget(
      MaterialApp(theme: AppTheme.dark, home: const HomeScreen()),
    );
    expect(find.text('ESP32 Offline'), findsOneWidget);
    expect(find.text('Not Connected'), findsOneWidget);
    expect(
      tester
          .widgetList<DashboardStatCard>(find.byType(DashboardStatCard))
          .map((card) => card.value),
      everyElement(0),
    );
    expect(find.text('DEMO / SAMPLE VALUES'), findsOneWidget);
    expect(find.text('No tests recorded yet'), findsOneWidget);
    expect(find.text('Notifications'), findsNothing);
    expect(find.byIcon(Icons.notifications_outlined), findsNothing);
    expect(
      tester
          .widget<NavigationBar>(find.byType(NavigationBar))
          .destinations
          .length,
      3,
    );

    for (final label in ['START VEHICLE TEST', 'START OFFICE TEST']) {
      await tapVisible(tester, find.text(label));
      expect(
        find.text(
          label == 'START VEHICLE TEST'
              ? 'Vehicle Safety Test'
              : 'Office Safety Test',
        ),
        findsOneWidget,
      );
      await tester.pageBack();
      await tester.pumpAndSettle();
      expect(find.byType(HomeScreen), findsOneWidget);
    }
    final actions = {
      'Device Status':
          'SafeStart ESP32 is offline. Reconnecting automatically.',
    };
    for (final action in actions.entries) {
      await tapVisible(tester, find.widgetWithText(ListTile, action.key));
      expect(find.text(action.value), findsOneWidget);
    }
    await tapVisible(
      tester,
      find.descendant(
        of: find.byType(NavigationBar),
        matching: find.text('Home'),
      ),
    );
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'Both History entries open History and Home returns to the same dashboard',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(theme: AppTheme.dark, home: const HomeScreen()),
      );
      final home = tester.element(find.byType(HomeScreen));
      for (final quickAction in [true, false]) {
        await tapVisible(
          tester,
          quickAction
              ? find.widgetWithText(ListTile, 'History')
              : find.descendant(
                  of: find.byType(NavigationBar),
                  matching: find.text('History'),
                ),
        );
        expect(find.byType(HistoryScreen), findsOneWidget);
        expect(
          tester
              .widget<NavigationBar>(find.byType(NavigationBar))
              .selectedIndex,
          1,
        );
        await tapVisible(
          tester,
          find.descendant(
            of: find.byType(NavigationBar),
            matching: find.text('Home'),
          ),
        );
        expect(tester.element(find.byType(HomeScreen)), same(home));
        expect(
          tester
              .widgetList<DashboardStatCard>(find.byType(DashboardStatCard))
              .every((card) => card.value == 0),
          isTrue,
        );
      }
    },
  );

  for (final size in [const Size(320, 640), const Size(1000, 800)]) {
    testWidgets('Dashboard scrolls without overflow at $size', (tester) async {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(
        MaterialApp(
          theme: AppTheme.dark,
          builder: (context, child) => MediaQuery(
            data: MediaQuery.of(context)
                .copyWith(textScaler: const TextScaler.linear(1.3)),
            child: child!,
          ),
          home: const HomeScreen(),
        ),
      );
      await tester.pumpAndSettle();
      await tapVisible(tester, find.text('START OFFICE TEST'));
      await tester.pageBack();
      await tester.pumpAndSettle();
      await tapVisible(tester, find.widgetWithText(ListTile, 'Device Status'));
      expect(tester.takeException(), isNull);
    });
  }
}
